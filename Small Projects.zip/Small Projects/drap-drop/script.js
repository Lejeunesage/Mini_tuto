let element = document.getElementById("element");
let isDragging = false;

element.addEventListener("mousedown", function(event) {
    isDragging = true;
});

document.addEventListener("mousemove", function(event) {
    if (isDragging) {
        element.style.left = event.pageX + "px";
        element.style.top = event.pageY + "px";
    }
});

document.addEventListener("mouseup", function(event) {
    isDragging = false;
});
