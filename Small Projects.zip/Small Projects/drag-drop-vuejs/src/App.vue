<script setup>
import { ref } from "vue";


let isDragging = ref(false) ;
  let startX = ref(0);
  let startY = ref(0) ;
  let x = ref(0)  
  let y = ref(0);
   

    function dragStart(event) {
      isDragging.value = true;
      startX.value = event.clientX;
      startY.value = event.clientY;
      console.log(isDragging.value);
      console.log(startX.value );
      console.log(startY.value );
      console.log(x.value );
      console.log(y.value );
    } ;
    
    function drag(event) {
      if (isDragging.value) {
        const dx = event.clientX - startX.value;
        const dy = event.clientY - startY.value;
        x.value += dx;
        y.value += dy;
        startX.value = event.clientX;
        startY.value = event.clientY;
        
        console.log(isDragging.value);
        console.log(startX.value );
        console.log(startY.value );
        console.log(x.value );
        console.log(y.value );
      };
    }
    
    
    function dragEnd() {
      isDragging.value = false;
      console.log(isDragging.value);
      console.log(startX.value );
      console.log(startY.value );
      console.log(x.value );
      console.log(y.value );
    };
    


</script>

<template>
  <div
class="drag"
      :style="{ left: x+'px', top: y+'px' }"
      @mousedown="dragStart"
      @mousemove="drag"
      @mouseup="dragEnd"
  >
 
  </div>
</template>

<style>
.drag{
  position: absolute;
  color: white;
  display: flex;

align-items: center;
justify-content: center;
  left: 50px;
  top: 50px;
  width: 200px;
  height: 200px;
  background-color: red;
  cursor: pointer;
}

</style>

