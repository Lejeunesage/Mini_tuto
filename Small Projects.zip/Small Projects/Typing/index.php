<?php
// Connexion à la base de données
$dbHost = "localhost";
$dbName = "typing";
$dbUser = "root";
$dbPassword = "";
$db = new PDO("mysql:host=$dbHost;dbname=$dbName", $dbUser, $dbPassword);

// Récupération des données du formulaire
$accuracy = $_POST["accuracy"];
$speed = $_POST["speed"];
$time = $_POST["time"];

// Insertion des données dans la base de données
$stmt = $db->prepare("INSERT INTO test_results (accuracy, speed, time) VALUES (:accuracy, :speed, :time)");
$stmt->bindParam(":accuracy", $accuracy);
$stmt->bindParam(":speed", $speed);
$stmt->bindParam(":time", $time);
$stmt->execute();
?>

<!-- Dans ce code, nous utilisons la classe PDO pour établir une connexion avec la base de données MySQL. Ensuite, nous récupérons les données du formulaire envoyé par le test de frappe au clavier et nous les insérons dans la table test_results de la base de données à l'aide d'une requête préparée.

Bien sûr, ce code est un exemple et peut être adapté en fonction de votre propre base de données et de votre schéma de table. Vous pouvez également ajouter des validations de données supplémentaires pour vous assurer que les données sont correctement formatées avant de les enregistrer dans la base de données. -->


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <h1>Test de vitesse de frappe au clavier</h1>
    <p>Cliquez sur le bouton "Démarrer" pour commencer le test.</p>
    <button id="start-button">Démarrer</button>
    <p>Appuyez sur les touches suivantes dans l'ordre:</p>
    <p id="sentence"></p>
    <textarea id="input-area" disabled></textarea>
    <p>Temps écoulé: <span id="timer">0</span> secondes</p>
    <p>Précision: <span id="accuracy">0</span>%</p>
    <p>Vitesse de frappe: <span id="wpm">0</span> mots par minute</p>
    <form action="" method="post">
        <input type="text" name="accuracy" id="timer" >
        <input type="text" name="speed" id="accuracy">
        <input type="text" name="time" id="wpm">
        <input type="submit" value="Autosend">
    </form>

    <?php

        // Récupération des résultats de la base de données
        $stmt = $db->query("SELECT * FROM test_results ORDER BY id DESC LIMIT 10");
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Affichage des résultats
        echo "<h2>Résultats précédents</h2>";
        echo "<table>";
        echo "<tr><th>Précision</th><th>Vitesse</th><th>Temps</th></tr>";
        foreach ($results as $row) {
        $accuracy = $row["accuracy"];
        $speed = $row["speed"];
        $time = $row["time"];
        echo "<tr><td>$accuracy%</td><td>$speed mots/min</td><td>$time secondes</td></tr>";
        }
        echo "</table>";
        ?>

        <!-- Dans ce code, nous exécutons une requête SQL pour récupérer les 10 derniers enregistrements de la table test_results, triés par ordre décroissant de leur identifiant. Nous utilisons ensuite une boucle foreach pour parcourir les résultats et les afficher dans une table HTML.

        Bien sûr, vous pouvez personnaliser la requête SQL pour récupérer des résultats différents ou ajouter des filtres pour afficher des résultats spécifiques. Vous pouvez également personnaliser le code HTML pour afficher les résultats de la manière que vous préférez. -->


        <?php
// Démarrage de la session
session_start();

// Vérification si l'utilisateur a déjà commencé le test
if (isset($_SESSION["started"])) {
  // L'utilisateur a déjà commencé le test
  if (isset($_POST["accuracy"]) && isset($_POST["speed"]) && isset($_POST["time"])) {
    // Enregistrement des résultats de l'utilisateur
    $accuracy = $_POST["accuracy"];
    $speed = $_POST["speed"];
    $time = $_POST["time"];
    $results = array("accuracy" => $accuracy, "speed" => $speed, "time" => $time);
    $_SESSION["results"][] = $results;
  }
  // Affichage des résultats précédents
  echo "<h2>Résultats précédents</h2>";
  echo "<table>";
  echo "<tr><th>Précision</th><th>Vitesse</th><th>Temps</th></tr>";
  foreach ($_SESSION["results"] as $row) {
    $accuracy = $row["accuracy"];
    $speed = $row["speed"];
    $time = $row["time"];
    echo "<tr><td>$accuracy%</td><td>$speed mots/min</td><td>$time secondes</td></tr>";
  }
  echo "</table>";
} else {
  // L'utilisateur n'a pas encore commencé le test
  $_SESSION["started"] = true;
  $_SESSION["results"] = array();
  // Affichage du formulaire de test
  echo "<h2>Test de frappe au clavier</h2>";
  echo "<form method='post'>";
  echo "<p>Entrez le texte ci-dessous :</p>";
  echo "<p>...</p>";
  echo "<p><label for='accuracy'>Précision (%):</label><input type='number' name='accuracy' required></p>";
  echo "<p><label for='speed'>Vitesse (mots/min):</label><input type='number' name='speed' required></p>";
  echo "<p><label for='time'>Temps (secondes):</label><input type='number' name='time' required></p>";
  echo "<input type='submit' value='Enregistrer les résultats'>";
  echo "</form>";
}

// Fermeture de la session
session_write_close();
?>


<!-- Dans ce code, nous utilisons la fonction session_start() pour démarrer une session. Nous vérifions ensuite si l'utilisateur a déjà commencé le test en vérifiant si la variable de session started est définie. Si c'est le cas, nous affichons les résultats précédents en utilisant les résultats enregistrés dans la variable de session results. Sinon, nous initialisons la session en définissant la variable de session started à true et en créant un tableau vide pour stocker les résultats de l'utilisateur.

Nous utilisons ensuite un formulaire pour permettre à l'utilisateur d'entrer les résultats du test. Si le formulaire est soumis, nous enregistrons les résultats dans un tableau associatif et nous ajoutons ce tableau au tableau des résultats de l'utilisateur dans la variable de session results.

Enfin, nous utilisons la fonction session_write_close() pour fermer la session et libérer les ressources. -->

    

    

<script src="script.js"></script>
</body>
</html>