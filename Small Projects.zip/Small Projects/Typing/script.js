const sentence = "La science est la connaissance que tu as d’une personne ou de quelque chose.";
const inputArea = document.getElementById("input-area");
const startButton = document.getElementById("start-button");
const accuracyDisplay = document.getElementById("accuracy");
const wpmDisplay = document.getElementById("wpm");
const timerDisplay = document.getElementById("timer");
let startTime, endTime;

function startTest() {
  inputArea.disabled = false;
  inputArea.value = "";
  inputArea.focus();
  startButton.disabled = true;
  startTime = new Date().getTime();
  displaySentence();
}

function displaySentence() {
  const sentenceDisplay = document.getElementById("sentence");
  sentenceDisplay.innerHTML = sentence;
}

function endTest() {
  endTime = new Date().getTime();
  const timeDiff = endTime - startTime;
  const seconds = timeDiff / 1000;
  const words = sentence.split(" ");
  const wordCount = words.length;
  const typedWords = inputArea.value.trim().split(" ");
  const typedWordCount = typedWords.length;
  let correctCount = 0;
  for (let i = 0; i < typedWordCount; i++) {
    if (typedWords[i] === words[i]) {
      correctCount++;
    }
  }
  const accuracy = (correctCount / wordCount) * 100;
  const wpm = Math.round((typedWordCount / seconds) * 60);
  accuracyDisplay.innerHTML = accuracy.toFixed(2);
  wpmDisplay.innerHTML = wpm;
  timerDisplay.innerHTML = seconds.toFixed(1);
  startButton.disabled = false;
  inputArea.disabled = true;
}

startButton.addEventListener("click", startTest);
inputArea.addEventListener("keyup", function(event) {
  if (event.key === "Enter" && inputArea.value.trim() !== "") {
    endTest();
  }
});

// Ce code crée une interface utilisateur simple avec un bouton "Démarrer" qui lance le test. Une phrase est affichée en haut de la page et l'utilisateur doit la taper dans la zone de texte. Une fois que l'utilisateur a terminé de taper la phrase, le temps écoulé, la précision et la vitesse de frappe sont calculés et affichés.

// Le code fonctionne en calculant le temps écoulé entre le début et la fin du test, en comparant les mots tapés par l'utilisateur avec les mots de la phrase d'origine pour calculer la précision, et en calculant le nombre de mots tapés par minute pour la vitesse



function displayResults() {
    const resultContainer = document.createElement("div");
    resultContainer.id = "result-container";
  
    const resultTitle = document.createElement("h2");
    resultTitle.innerHTML = "Résultats du test de frappe au clavier";
  
    const accuracyContainer = document.createElement("div");
    const accuracyTitle = document.createElement("h3");
    accuracyTitle.innerHTML = "Précision : ";
    const accuracyValue = document.createElement("span");
    accuracyValue.innerHTML = `${accuracy.toFixed(2)}%`;
    accuracyContainer.appendChild(accuracyTitle);
    accuracyContainer.appendChild(accuracyValue);
  
    const wpmContainer = document.createElement("div");
    const wpmTitle = document.createElement("h3");
    wpmTitle.innerHTML = "Vitesse de frappe : ";
    const wpmValue = document.createElement("span");
    wpmValue.innerHTML = `${wpm} mots par minute`;
    wpmContainer.appendChild(wpmTitle);
    wpmContainer.appendChild(wpmValue);
  
    const restartButton = document.createElement("button");
    restartButton.innerHTML = "Recommencer";
    restartButton.addEventListener("click", () => {
      resultContainer.remove();
      startTest();
    });
  
    resultContainer.appendChild(resultTitle);
    resultContainer.appendChild(accuracyContainer);
    resultContainer.appendChild(wpmContainer);
    resultContainer.appendChild(restartButton);
    document.body.appendChild(resultContainer);
  }
  
  function endTest() {
    endTime = new Date().getTime();
    const timeDiff = endTime - startTime;
    const seconds = timeDiff / 1000;
    const words = sentence.split(" ");
    const wordCount = words.length;
    const typedWords = inputArea.value.trim().split(" ");
    const typedWordCount = typedWords.length;
    let correctCount = 0;
    for (let i = 0; i < typedWordCount; i++) {
      if (typedWords[i] === words[i]) {
        correctCount++;
      }
    }
    const accuracy = (correctCount / wordCount) * 100;
    const wpm = Math.round((typedWordCount / seconds) * 60);
    accuracyDisplay.innerHTML = accuracy.toFixed(2);
    wpmDisplay.innerHTML = wpm;
    timerDisplay.innerHTML = seconds.toFixed(1);
    startButton.disabled = false;
    inputArea.disabled = true;
    displayResults();
}


// Dans cette version du code, j'ai ajouté une fonction displayResults qui est appelée lorsque le test est terminé. Cette fonction crée une nouvelle section HTML qui affiche les résultats du test, y compris la précision et la vitesse de frappe, ainsi qu'un bouton "Recommencer" qui permet à l'utilisateur de lancer un nouveau test.

// J'ai également modifié la fonction endTest pour appeler la fonction displayResults à la fin du test, et j'ai supprimé les affichages de précision et de vitesse de frappe dans l'interface utilisateur principale, car ils sont maintenant affichés dans la section de résultats.


// Connexion au serveur WebSocket
var socket = new WebSocket("ws://localhost:8080");

// Événement déclenché lorsque la connexion est établie
socket.onopen = function(event) {
  console.log("Connexion établie");
}

// Événement déclenché lorsque le serveur envoie un message
socket.onmessage = function(event) {
  var message = JSON.parse(event.data);
  if (message.type == "start") {
    // Le serveur a envoyé un message de démarrage du test
    startTest(message.text);
  } else if (message.type == "stop") {
    // Le serveur a envoyé un message d'arrêt du test
    stopTest();
  }
}

// Fonction pour démarrer le test
function startTest(text) {
  var startTime = new Date().getTime();
  var typedText = "";
  var index = 0;
  var accuracy = 0;
  var speed = 0;
  var time = 0;

  // Affichage du texte à saisir
  document.getElementById("text").innerHTML = text;

  // Événement déclenché lorsque l'utilisateur tape une touche
  document.addEventListener("keydown", function(event) {
    if (event.key.length == 1) {
      // La touche est une lettre, un chiffre ou un symbole
      typedText += event.key;
      if (event.key == text[index]) {
        // La touche correspond au caractère attendu
        index++;
        accuracy = Math.round(index / text.length * 10000) / 100;
        document.getElementById("accuracy").innerHTML = accuracy + "%";
        if (index == text.length) {
          // L'utilisateur a terminé le test
          var endTime = new Date().getTime();
          var elapsedTime = (endTime - startTime) / 1000;
          speed = Math.round(text.length / elapsedTime * 60);
          time = Math.round(elapsedTime * 100) / 100;
          document.getElementById("speed").innerHTML = speed + " mots/min";
          document.getElementById("time").innerHTML = time + " secondes";
          // Envoi des résultats au serveur via WebSocket
          var results = {"accuracy": accuracy, "speed": speed, "time": time};
          socket.send(JSON.stringify(results));
        }
      }
    } else if (event.keyCode == 8 && typedText.length > 0) {
      // La touche est la touche Backspace
      typedText = typedText.substring(0, typedText.length - 1);
      index--;
      accuracy = Math.round(index / text.length * 10000) / 100;
      document.getElementById("accuracy").innerHTML = accuracy + "%";
    }
  });
}

// Fonction pour arrêter le test
function stopTest() {
  // Suppression de l'événement pour éviter les saisies supplémentaires
  document.removeEventListener("keydown", function(event) {});
}


// Dans ce code, nous utilisons la classe WebSocket pour établir une connexion avec le serveur WebSocket à l'adresse ws://localhost:8080. Nous définissons ensuite deux événements : onopen pour afficher un message dans la console lorsque la connexion est établie, et onmessage pour traiter les messages envoyés par le serveur.

// Si le serveur envoie un message de type "start", nous appelons la fonction startTest()





