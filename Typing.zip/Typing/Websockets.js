// Connexion au serveur WebSocket
var socket = new WebSocket("ws://localhost:8080");

// Événement déclenché lorsque la connexion est établie
socket.onopen = function(event) {
  console.log("Connexion établie");
}

// Événement déclenché lorsque le serveur envoie un message
socket.onmessage = function(event) {
  var message = JSON.parse(event.data);
  if (message.type == "start") {
    // Le serveur a envoyé un message de démarrage du test
    startTest(message.text);
  } else if (message.type == "stop") {
    // Le serveur a envoyé un message d'arrêt du test
    stopTest();
  }
}

// Fonction pour démarrer le test
function startTest(text) {
  var startTime = new Date().getTime();
  var typedText = "";
  var index = 0;
  var accuracy = 0;
  var speed = 0;
  var time = 0;

  // Affichage du texte à saisir
  document.getElementById("text").innerHTML = text;

  // Événement déclenché lorsque l'utilisateur tape une touche
  document.addEventListener("keydown", function(event) {
    if (event.key.length == 1) {
      // La touche est une lettre, un chiffre ou un symbole
      typedText += event.key;
      if (event.key == text[index]) {
        // La touche correspond au caractère attendu
        index++;
        accuracy = Math.round(index / text.length * 10000) / 100;
        document.getElementById("accuracy").innerHTML = accuracy + "%";
        if (index == text.length) {
          // L'utilisateur a terminé le test
          var endTime = new Date().getTime();
          var elapsedTime = (endTime - startTime) / 1000;
          speed = Math.round(text.length / elapsedTime * 60);
          time = Math.round(elapsedTime * 100) / 100;
          document.getElementById("speed").innerHTML = speed + " mots/min";
          document.getElementById("time").innerHTML = time + " secondes";
          // Envoi des résultats au serveur via WebSocket
          var results = {"accuracy": accuracy, "speed": speed, "time": time};
          socket.send(JSON.stringify(results));
        }
      }
    } else if (event.keyCode == 8 && typedText.length > 0) {
      // La touche est la touche Backspace
      typedText = typedText.substring(0, typedText.length - 1);
      index--;
      accuracy = Math.round(index / text.length * 10000) / 100;
      document.getElementById("accuracy").innerHTML = accuracy + "%";
    }
  });
}

// Fonction pour arrêter le test
function stopTest() {
  // Suppression de l'événement pour éviter les saisies supplémentaires
  document.removeEventListener("keydown", function(event) {});
}


// Dans ce code, nous utilisons la classe WebSocket pour établir une connexion avec le serveur WebSocket à l'adresse ws://localhost:8080. Nous définissons ensuite deux événements : onopen pour afficher un message dans la console lorsque la connexion est établie, et onmessage pour traiter les messages envoyés par le serveur.

// Si le serveur envoie un message de type "start", nous appelons la fonction startTest()





