<?php
// Connexion à la base de données
$dbHost = "localhost";
$dbName = "typing";
$dbUser = "root";
$dbPassword = "";
$db = new PDO("mysql:host=$dbHost;dbname=$dbName", $dbUser, $dbPassword);

// Récupération des données du formulaire
$accuracy = $_POST["accuracy"];
$speed = $_POST["speed"];
$time = $_POST["time"];

// Insertion des données dans la base de données
$stmt = $db->prepare("INSERT INTO test_results (accuracy, speed, time) VALUES (:accuracy, :speed, :time)");
$stmt->bindParam(":accuracy", $accuracy);
$stmt->bindParam(":speed", $speed);
$stmt->bindParam(":time", $time);
$stmt->execute();
?>

<!-- Dans ce code, nous utilisons la classe PDO pour établir une connexion avec la base de données MySQL. Ensuite, nous récupérons les données du formulaire envoyé par le test de frappe au clavier et nous les insérons dans la table test_results de la base de données à l'aide d'une requête préparée.

Bien sûr, ce code est un exemple et peut être adapté en fonction de votre propre base de données et de votre schéma de table. Vous pouvez également ajouter des validations de données supplémentaires pour vous assurer que les données sont correctement formatées avant de les enregistrer dans la base de données. -->

