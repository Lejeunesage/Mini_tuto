<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Typing</title>
    <link rel="stylesheet" href="/style.css">
</head>
<body>

  <main>
    <h1>Quelle est votre habileté au clavier?</h1>
    <h2>Evaluer votre vitesse et votre précision grâce à mon test de dactylographie gratuit.😂🤣</h2>
      <h3 style="color:indigo" >
        Ecrivez les mots ci-dessous dans l'ordre sans faire d'erreurs et sans en ommettre un.
      </h3>
      <p>
        Appuyez sur le bouton démarrer pour commencer.
      </p>
      <button id="start-button">
        Démarrer
      </button>
      <p id="sentence" class="sentence"></p>
      <textarea id="input-area" disabled></textarea>
      <button id="restart-button" >
        Recommencer
      </button>
      <div id="results">
        <p>Temps écoulé: <span id="timer">0</span> secondes</p>
        <p>Précision: <span id="accuracy">0</span>%</p>
        <p>
          Vitesse de frappe: <span id="wpm">0</span> mots par minute
        </p>
      </div>
  </main>
    
<script src="/script.js"></script>
</body>
</html>