// La phrase à saisir.

const sentence = "La clé du succès pour taper rapidement et avec précision consiste à utiliser tous ses doigts! Pour apprendre la bonne technique de frappe, utilisez une méthode adaptée à votre clavier. Pour bien jouer sur le clavier du piano, il ne faut surtout pas regarder ses doigts et les touches, mais se focaliser sur la partition.";


const inputArea = document.getElementById("input-area");
const startButton = document.getElementById("start-button");
const accuracyDisplay = document.getElementById("accuracy");
const wpmDisplay = document.getElementById("wpm");
const timerDisplay = document.getElementById("timer");
let startTime, endTime;

// Fonction permettant d'injecter la phrase dans la div.
function displaySentence() {
  const sentenceDisplay = document.getElementById("sentence");
  sentenceDisplay.style.color = "red";
  sentenceDisplay.style.lineHeight = "30px";
  sentenceDisplay.style.fontSize = "20px";
  // Permet d'injecter la phrase dans la div.
  sentenceDisplay.innerHTML = sentence;
}

// Fonction permettant d'afficher les resultat du test.
function displayResults() {
  const results = document.getElementById("results");
  results.style.display = "block";
}

// let count = 1;
// function decompt(){
//   setInterval(() => {
//     count = count++
//   }, 1000);
// }
// decompt();

// Fonction permettant de lancer le test.
function startTest() {
  // Pour rendre le text aréa disponible.
  inputArea.disabled = false;
  // Text aréa vide
  inputArea.value = "";
  inputArea.style.fontSize = "20px";
  // Pour mettre l'input focus
  inputArea.focus();
  // D&sactiver le bouton demarrer
  startButton.disabled = true;
  //Pour enrégister la date de debut du test en timestamps.
  startTime = new Date().getTime();
  //Afficher le texte dans la div.
  restartButton.style.display = 'none';
  results.style.display = "none";
  displaySentence();
  arret()
}

// Fonction d'arret du test.
function endTest() {
//Permet de récupérer la date de fin du test en timestamps.
  endTime = new Date().getTime();
  // permet de determeiner la durer du test.
  const timeDiff = endTime - startTime;
  const seconds = timeDiff / 1000;

  // Transformer la phrase en tableau javascrpt.
  const words = sentence.split(" ");

  // Permet de determeiner la longueur du texte à saisir.
  const wordCount = words.length;
  // Permet de recupérer le texte saisie.
  const typedWords = inputArea.value.trim().split(" ");
  
  // Permet de determiner la taille du texte reellement saisie. 
  const typedWordCount = typedWords.length;

  let correctCount = 0;
  for (let i = 0; i < typedWordCount; ++i) {
    if (typedWords[i] === words[i]) {
      correctCount++
    }

  }
  const accuracy = (correctCount / wordCount) * 100;


  // Permet de calculer la vitesse de saisie a clavier.
  // Pn divise le nombre de mot saisie par le nombre de seconde effectuer pour saisir le texte.Puis ensuite le multiplier par 60s.
  // const wpm = Math.round((typedWordCount / seconds) * 60);
  const wpm = Math.round((correctCount / seconds) * 60);

  // Permet d'afficher les données récuperer dans la vue.
  accuracyDisplay.innerHTML = accuracy.toFixed(2);
  wpmDisplay.innerHTML = wpm;
  timerDisplay.innerHTML = seconds.toFixed(1);
  startButton.disabled = false;
  inputArea.disabled = true;
  displayResults();
}

const restartButton = document.getElementById("restart-button");
   
restartButton.addEventListener("click", () => {
  startTest();
});

//Permet de lancer le test au clique sur le bouton demarrer. 
startButton.addEventListener("click", startTest);

// Permet d'arrèter le text au clique du bouton 'Entrer' sur le clavier.
inputArea.addEventListener("keyup", function(event) {
  if (event.key === "Enter" && inputArea.value.trim() !== "") {
    endTest();
    restartButton.style.display = 'block';
  }
});

function arret() {
  setTimeout(() => {
    if (inputArea.value.trim() !== "") {
      endTest();
      restartButton.style.display = 'block';
    }
  }, 60000);
}


// Ce code crée une interface utilisateur simple avec un bouton "Démarrer" qui lance le test. Une phrase est affichée en haut de la page et l'utilisateur doit la taper dans la zone de texte. Une fois que l'utilisateur a terminé de taper la phrase, le temps écoulé, la précision et la vitesse de frappe sont calculés et affichés.

// Le code fonctionne en calculant le temps écoulé entre le début et la fin du test, en comparant les mots tapés par l'utilisateur avec les mots de la phrase d'origine pour calculer la précision, et en calculant le nombre de mots tapés par minute pour la vitesse



// function displayResults() {
//     const resultContainer = document.createElement("div");
//     resultContainer.id = "result-container";
  
//     const resultTitle = document.createElement("h2");
//     resultTitle.innerHTML = "Résultats du test de frappe au clavier";
  
//     const accuracyContainer = document.createElement("div");
//     const accuracyTitle = document.createElement("h3");
//     accuracyTitle.innerHTML = "Précision : ";
//     const accuracyValue = document.createElement("span");
//     accuracyValue.innerHTML = `${accuracy.toFixed(2)}%`;
//     accuracyContainer.appendChild(accuracyTitle);
//     accuracyContainer.appendChild(accuracyValue);
  
//     const wpmContainer = document.createElement("div");
//     const wpmTitle = document.createElement("h3");
//     wpmTitle.innerHTML = "Vitesse de frappe : ";
//     const wpmValue = document.createElement("span");
//     wpmValue.innerHTML = `${wpm} mots par minute`;
//     wpmContainer.appendChild(wpmTitle);
//     wpmContainer.appendChild(wpmValue);
  
//     const restartButton = document.createElement("button");
//     restartButton.innerHTML = "Recommencer";
//     restartButton.addEventListener("click", () => {
//       resultContainer.remove();
//       startTest();
//     });
  
//     resultContainer.appendChild(resultTitle);
//     resultContainer.appendChild(accuracyContainer);
//     resultContainer.appendChild(wpmContainer);
//     resultContainer.appendChild(restartButton);
//     document.body.appendChild(resultContainer);
//   }
  
//   function endTest() {
//     endTime = new Date().getTime();
//     const timeDiff = endTime - startTime;
//     const seconds = timeDiff / 1000;
//     const words = sentence.split(" ");
//     const wordCount = words.length;
//     const typedWords = inputArea.value.trim().split(" ");
//     const typedWordCount = typedWords.length;
//     let correctCount = 0;
//     for (let i = 0; i < typedWordCount; i++) {
//       if (typedWords[i] === words[i]) {
//         correctCount++;
//       }
//     }
//     const accuracy = (correctCount / wordCount) * 100;
//     const wpm = Math.round((typedWordCount / seconds) * 60);
//     accuracyDisplay.innerHTML = accuracy.toFixed(2);
//     wpmDisplay.innerHTML = wpm;
//     timerDisplay.innerHTML = seconds.toFixed(1);
//     startButton.disabled = false;
//     inputArea.disabled = true;
//     displayResults();
  
// }


// Dans cette version du code, j'ai ajouté une fonction displayResults qui est appelée lorsque le test est terminé. Cette fonction crée une nouvelle section HTML qui affiche les résultats du test, y compris la précision et la vitesse de frappe, ainsi qu'un bouton "Recommencer" qui permet à l'utilisateur de lancer un nouveau test.

// J'ai également modifié la fonction endTest pour appeler la fonction displayResults à la fin du test, et j'ai supprimé les affichages de précision et de vitesse de frappe dans l'interface utilisateur principale, car ils sont maintenant affichés dans la section de résultats.


