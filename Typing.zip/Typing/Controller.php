<?php

        // Récupération des résultats de la base de données
        $stmt = $db->query("SELECT * FROM test_results ORDER BY id DESC LIMIT 10");
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Affichage des résultats
        echo "<h2>Résultats précédents</h2>";
        echo "<table>";
        echo "<tr><th>Précision</th><th>Vitesse</th><th>Temps</th></tr>";
        foreach ($results as $row) {
        $accuracy = $row["accuracy"];
        $speed = $row["speed"];
        $time = $row["time"];
        echo "<tr><td>$accuracy%</td><td>$speed mots/min</td><td>$time secondes</td></tr>";
        }
        echo "</table>";
        ?>

        <!-- Dans ce code, nous exécutons une requête SQL pour récupérer les 10 derniers enregistrements de la table test_results, triés par ordre décroissant de leur identifiant. Nous utilisons ensuite une boucle foreach pour parcourir les résultats et les afficher dans une table HTML.

        Bien sûr, vous pouvez personnaliser la requête SQL pour récupérer des résultats différents ou ajouter des filtres pour afficher des résultats spécifiques. Vous pouvez également personnaliser le code HTML pour afficher les résultats de la manière que vous préférez. -->


        <?php
// Démarrage de la session
session_start();

// Vérification si l'utilisateur a déjà commencé le test
if (isset($_SESSION["started"])) {
  // L'utilisateur a déjà commencé le test
  if (isset($_POST["accuracy"]) && isset($_POST["speed"]) && isset($_POST["time"])) {
    // Enregistrement des résultats de l'utilisateur
    $accuracy = $_POST["accuracy"];
    $speed = $_POST["speed"];
    $time = $_POST["time"];
    $results = array("accuracy" => $accuracy, "speed" => $speed, "time" => $time);
    $_SESSION["results"][] = $results;
  }
  // Affichage des résultats précédents
  echo "<h2>Résultats précédents</h2>";
  echo "<table>";
  echo "<tr><th>Précision</th><th>Vitesse</th><th>Temps</th></tr>";
  foreach ($_SESSION["results"] as $row) {
    $accuracy = $row["accuracy"];
    $speed = $row["speed"];
    $time = $row["time"];
    echo "<tr><td>$accuracy%</td><td>$speed mots/min</td><td>$time secondes</td></tr>";
  }
  echo "</table>";
} else {
  // L'utilisateur n'a pas encore commencé le test
  $_SESSION["started"] = true;
  $_SESSION["results"] = array();
  // Affichage du formulaire de test
  echo "<h2>Test de frappe au clavier</h2>";
  echo "<form method='post'>";
  echo "<p>Entrez le texte ci-dessous :</p>";
  echo "<p>...</p>";
  echo "<p><label for='accuracy'>Précision (%):</label><input type='number' name='accuracy' required></p>";
  echo "<p><label for='speed'>Vitesse (mots/min):</label><input type='number' name='speed' required></p>";
  echo "<p><label for='time'>Temps (secondes):</label><input type='number' name='time' required></p>";
  echo "<input type='submit' value='Enregistrer les résultats'>";
  echo "</form>";
}

// Fermeture de la session
session_write_close();
?>


<!-- Dans ce code, nous utilisons la fonction session_start() pour démarrer une session. Nous vérifions ensuite si l'utilisateur a déjà commencé le test en vérifiant si la variable de session started est définie. Si c'est le cas, nous affichons les résultats précédents en utilisant les résultats enregistrés dans la variable de session results. Sinon, nous initialisons la session en définissant la variable de session started à true et en créant un tableau vide pour stocker les résultats de l'utilisateur.

Nous utilisons ensuite un formulaire pour permettre à l'utilisateur d'entrer les résultats du test. Si le formulaire est soumis, nous enregistrons les résultats dans un tableau associatif et nous ajoutons ce tableau au tableau des résultats de l'utilisateur dans la variable de session results.

Enfin, nous utilisons la fonction session_write_close() pour fermer la session et libérer les ressources. -->
